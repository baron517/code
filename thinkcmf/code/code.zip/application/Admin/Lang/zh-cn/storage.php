<?php
return array(
    "DEFAULT" => '系统默认',
    "QINIU" => "七牛云存储",
    "DOMAIN" => '空间域名',
    "BUCKET" => '空间名称',
    "GET_ACCESS_KEY" => '获取AccessKey',
    "QINIU_PROMOTION_CODE" => 'ThinkCMF七牛专享优惠码',
    "GET_IT_NOW" => '马上获取'
);