<?php
return array(
		'send_mobile_verify_code',
);