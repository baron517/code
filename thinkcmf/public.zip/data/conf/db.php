<?php
/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'xiuqiu',
    'DB_USER' => 'root',
    'DB_PWD' => 'tuyao19910715',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'tb_',
    //密钥
    "AUTHCODE" => 'yW5ysjO3joU5OLeFX9',
    //cookies
    "COOKIE_PREFIX" => '9o4COW_',
);
