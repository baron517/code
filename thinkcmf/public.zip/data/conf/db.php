<?php

/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'sheying',
    'DB_USER' => 'root',
    'DB_PWD' => 'tuyao19910715',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'tb_',
    //密钥
    "AUTHCODE" => 'yW5ysjO3joU5OLeFX9',
    //cookies
    "COOKIE_PREFIX" => '9o4COW_',
    "SERVER_URL"=>'https://sy.pro.youzewang.com',
    "NAME"=>'摄影后台管理',
    
    //小程序
    "Appid"=>'wx14d40022ef21aaf8',
    "AppSecret"=>'33f599632b37da0328daedc86d4c27e8',
    
    //微信支付
    "Api"=>'6t4k2icgune9IvZgkinMhXGwVhR85QtF',
    "Mch_id"=>'1516368681',
    
    
    
);
