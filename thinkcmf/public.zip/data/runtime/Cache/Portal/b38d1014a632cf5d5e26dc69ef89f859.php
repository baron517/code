<?php if (!defined('THINK_PATH')) exit();?><script>
    
    window.location.href="/admin"
    
</script>