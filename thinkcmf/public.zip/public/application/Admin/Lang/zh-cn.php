<?php

return array(
		'ADMIN_CENTER' => '后台管理中心',
		'WELCOME_USER' => '欢迎, {$username}',
		'WEBSITE_HOME_PAGE' => '网站首页'
		
);