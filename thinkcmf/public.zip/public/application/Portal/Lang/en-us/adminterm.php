<?php
return array(
    "NAME" => 'Category Name',
    "CATEGORY_TYPE" => 'Category Type',
    "CATEGORY_URL" => 'URL',
    "ADD_SUB_CATEGORY" => 'Add Sub Category',
    "CATEGORY_DESCRIPTION" => 'Description',
    "PARENT" => 'Parent',
    "ROOT" => 'Root',
    "SEO_TITLE" => 'SEO Title',
    "SEO_KEYWORDS" => 'SEO Keywords',
    "SEO_DESCRIPTION" => 'SEO Description',
    "LIST_TEMPLATE" => 'List Template',
    "ARTICLE_TEMPLATE" => 'Article Template',
    "GENERAL_SETTING" => 'General Setting',
    "SEO_SETTING" => 'SEO Setting',
    "TEMPLATE_SETTING" => 'Template Setting'
);